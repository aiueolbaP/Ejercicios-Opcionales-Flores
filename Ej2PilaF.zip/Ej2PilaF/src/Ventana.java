import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel principal;
    private JTextArea txtCodigo;
    private JButton btnComprobar;
    private JLabel lblCodigo;
    private JTextArea txtPila;
    private JLabel txtPilaTiempoReal;

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    Pila p = new Pila();
                    String codigo = txtCodigo.getText();

                    for (int i = 0; i <= codigo.length() - 1; i++) {
                        char c = codigo.charAt(i);
                        if (c == '(' || c == '[' || c == '{') {
                            p.insertar(String.valueOf(c));
                            JOptionPane.showMessageDialog(null, "Se inserta el caracter: " + c);
                            txtPila.setText(p.toString());
                        } else if (c == ')' || c == ']' || c == '}') {
                            if (p.esVacia()) {
                                JOptionPane.showMessageDialog(null, "Codigo incorrecto");
                                return;
                            }
                            char salida = p.extraer().charAt(0);
                            JOptionPane.showMessageDialog(null, "Se extrajo: " + salida);
                            txtPila.setText(p.toString());

                            if ((c == ')' && salida != '(') ||
                                    (c == ']' && salida != '[') ||
                                    (c == '}' && salida != '{')) {
                                JOptionPane.showMessageDialog(null, "Codigo incorrecto");
                                return;
                            }
                        }

                    }
                    if (p.esVacia()) {
                        JOptionPane.showMessageDialog(null, "Codigo correcto");
                        txtCodigo.setText("");

                    } else {
                        JOptionPane.showMessageDialog(null, "Codigo incorrecto");
                    }
                } catch ( Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());

                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
