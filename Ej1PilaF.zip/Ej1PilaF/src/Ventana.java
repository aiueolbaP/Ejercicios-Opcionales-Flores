import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    //Nombre recomendable por ser el panel principal
    private JPanel principal;
    private JTextField txtString;
    private JButton btnApilar;
    private JButton btnDesapilar;
    private JTextArea txtMostrar;
    private JLabel lblEtiqueta;
    private JButton btnMostrar;
    //Generar pila global para usarlo en metodos
    private Pila lista = new Pila();

    public Ventana() {
        btnApilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //El text field tiene el metodo para sacar lo que se ha ingresado
                try{
                    lista.apilar(txtString.getText());
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

                //Poner el texto que se muestra con el metodo que hicimos
                txtString.setText("");
                txtMostrar.setText(lista.toString());

            }
        });
        btnDesapilar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Guardamos lo eliminado en una variable para mostrar al usuario lo que fue desapilado
                try{
                    String eliminado = lista.desapilar();
                    JOptionPane.showMessageDialog(null, "Eliminado: " +  eliminado);
                    txtMostrar.setText(lista.toString());
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());

                }


            }
        });
        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    String cima = lista.cima();
                    JOptionPane.showMessageDialog(null, "Primer elemento: "+cima);
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
        });
    }


    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
