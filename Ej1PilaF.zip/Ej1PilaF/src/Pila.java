import java.util.Stack;

public class Pila {

    private Stack<String> arreglo;
    //Para hacer que solo ingresen elementos String a la pila

    public Pila(){
        arreglo = new Stack<String>();
    }


    public void apilar(String dato) throws Exception {

            if(arreglo.size() < 10){
                arreglo.push(dato);
            }else {

            throw new Exception("La pila contiene el número máximo de objetos");
        }

    }

    //Si no se especifica el tipo de dato de la pila este método dará error
    public String desapilar() throws Exception {
        if(arreglo.isEmpty())
            throw new Exception("La pila está vacía");
        return arreglo.pop();
    }

    //Ver el primer elemento sin quitarlo de la pila
    public String cima() throws Exception{
        if(arreglo.isEmpty())
            throw new Exception("La pila está vacía");
        return arreglo.peek();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        //Para empezar en la última ubicación de la pila
        for(int i = (arreglo.size()-1); i >= 0; i--){
            sb.append(arreglo.get(i)+"\n");

        }

        return sb.toString();
    }
}
