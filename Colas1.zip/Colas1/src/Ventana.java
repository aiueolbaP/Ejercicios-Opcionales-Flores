import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.Date;

public class Ventana {
    private JPanel principal;
    private JComboBox cboMarca;
    private JTextField txtAnio;
    private JButton btnEncolar;
    private JButton btnDesencolar;
    private JTextArea txtListaAutos;
    private JLabel lblAutoAtendido;
    private ColaAutos listaAutos = new ColaAutos();

    public Ventana() {
        btnEncolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String marca = cboMarca.getSelectedItem().toString(); //para sacar texto de un combo box
                int anio = Integer.parseInt(txtAnio.getText());
                listaAutos.encolar(new Auto(marca, anio));
                txtListaAutos.setText(listaAutos.listarTodos());
            }
        });
        btnDesencolar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Auto atendido = listaAutos.desencolar();
                    double total = listaAutos.calcularPrecio(Integer.parseInt(txtAnio.getText()));
                    lblAutoAtendido.setText(atendido.toString()+ ", total a pagar: "+String.valueOf(total) + "$");
                    txtListaAutos.setText(listaAutos.listarTodos());
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.pack();
        frame.setSize(1080, 720);
        frame.setVisible(true);

    }
}
